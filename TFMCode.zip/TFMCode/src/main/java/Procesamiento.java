import com.mongodb.client.*;
import org.eclipse.paho.client.mqttv3.*;
import com.espertech.esper.client.*;
import org.json.JSONObject;
import org.json.JSONException;
import com.mongodb.client.model.Filters;
import org.bson.Document;
import com.mongodb.MongoClientSettings;
import com.mongodb.ConnectionString;

import java.util.HashMap;
import java.util.Map;


public class Procesamiento {
    private static String[] sensorNames;
    private static int[] sensorUmbrals;
    private static Map<String, Integer> sensorThresholds = new HashMap<>();
    private static EPRuntime cepRT;
    public static void main(String[] args) {
        String broker = "ws://test.mosquitto.org:8080/mqtt";
        String clientId = "JavaMQTTSubscriber";
        String topic = "TFM_Sensores";
        sensorThresholds = obtenerUmbralesSensores();
    }
    public static Map<String, Integer> obtenerUmbralesSensores() {
        Map<String, Integer> sensorThresholds = new HashMap<>();

        ConnectionString connectionString = new ConnectionString("mongodb+srv://plataformaPMR:NT0RHvpfC0KMgbra@cluster0.cae2jjy.mongodb.net/platformtfm");
        MongoClientSettings settings = MongoClientSettings.builder()
                .applyConnectionString(connectionString)
                .build();
        MongoClient mongoClient = MongoClients.create(settings);
        MongoDatabase database = mongoClient.getDatabase("platformtfm");
        MongoCollection<Document> collection = database.getCollection("sensors");
        MongoCursor<Document> cursor = collection.find().iterator();
        try {
            while (cursor.hasNext()) {
                Document sensor = cursor.next();
                String name = sensor.getString("name");
                int threshold = sensor.getInteger("umbral");
                sensorThresholds.put(name, threshold);
            }
        } finally {
            cursor.close();
        }
        for (Map.Entry<String, Integer> entry : sensorThresholds.entrySet()) {
            System.out.println("Nombre del sensor: " + entry.getKey() + ", Umbral: " + entry.getValue());
        }

        return sensorThresholds; // Devolver el mapa de umbrales
    }
}
