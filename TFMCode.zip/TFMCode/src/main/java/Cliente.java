import com.mongodb.client.*;
import org.eclipse.paho.client.mqttv3.*;
import com.espertech.esper.client.*;
import org.json.JSONObject;
import org.json.JSONException;
import com.mongodb.client.model.Filters;
import org.bson.Document;
import com.mongodb.MongoClientSettings;
import com.mongodb.ConnectionString;

public class Cliente {
    private static int pulsoUmbral;
    private static int saturacionUmbral;
    private static int acelerometroUmbral;
    // Variables para los sensores
    private static String[] sensorNames;
    private static int[] sensorUmbrals;
    public static void main(String[] args) {
        String broker = "ws://test.mosquitto.org:8080/mqtt";
        String clientId = "JavaMQTTSubscriber";
        String topic = "TFM_Salud";

        obtenerUmbrales();

        try {
            MqttClient client = new MqttClient(broker, clientId);
            client.setCallback(new MqttCallback() {
                public void connectionLost(Throwable cause) {
                    System.out.println("Conexión perdida con el broker MQTT");
                }
                public void messageArrived(String topic, MqttMessage message) throws Exception {
                    System.out.println("Mensaje recibido en el topic " + topic + ": " + new String(message.getPayload()));
                    if (topic.equals(topic)) {
                        procesarMensaje(new String(message.getPayload()));
                    }
                }
                public void deliveryComplete(IMqttDeliveryToken token) {
                }
            });

            client.connect();
            client.subscribe(topic);
            System.out.println("Conectado al broker MQTT y suscrito al tópico: " + topic );
            Configuration config = new Configuration();
            config.addEventType("Mensaje", Mensaje.class);

            EPServiceProvider serviceProvider = EPServiceProviderManager.getDefaultProvider(config);
            EPRuntime runtime = serviceProvider.getEPRuntime();

            EPStatement statement = serviceProvider.getEPAdministrator().createEPL("select * from Mensaje where pulso > " + pulsoUmbral + " or saturacion < " + saturacionUmbral + " or acelerometro > " + acelerometroUmbral);
            statement.addListener((newData, oldData) -> {
                if (newData[0].getUnderlying() instanceof Mensaje) {
                    Mensaje mensaje = (Mensaje) newData[0].getUnderlying();
                    if (mensaje.getPulso() > pulsoUmbral) {
                        System.out.println("¡Alerta! Pulso demasiado alto: " + mensaje.getPulso());
                    }
                    if (mensaje.getSaturacion() < saturacionUmbral) {
                        System.out.println("¡Alerta! Saturación baja: " + mensaje.getSaturacion());
                    }
                    if (mensaje.getAcelerometro() > acelerometroUmbral) {
                        System.out.println("¡Alerta! Peligro de caida: " + mensaje.getAcelerometro());
                    }
                }
            });
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    public static void procesarMensaje(String mensajeJSON) {
        Configuration config = new Configuration();
        config.addEventType("Mensaje", Mensaje.class);

        EPServiceProvider serviceProvider = EPServiceProviderManager.getDefaultProvider(config);
        EPRuntime runtime = serviceProvider.getEPRuntime();

        runtime.sendEvent(new Mensaje(mensajeJSON));
    }
    public static void obtenerUmbrales() {
        try {
            // Conexión a MongoDB Atlas
            ConnectionString connectionString = new ConnectionString("mongodb+srv://plataformaPMR:NT0RHvpfC0KMgbra@cluster0.cae2jjy.mongodb.net/platformtfm");
            MongoClientSettings settings = MongoClientSettings.builder()
                    .applyConnectionString(connectionString)
                    .build();
            MongoClient mongoClient = MongoClients.create(settings);
            MongoDatabase database = mongoClient.getDatabase("platformtfm");
            MongoCollection<Document> collection = database.getCollection("umbrales");
            Document umbralesDocument = collection.find().first();
            if (umbralesDocument != null) {
                pulsoUmbral = umbralesDocument.getInteger("pulso");
                saturacionUmbral = umbralesDocument.getInteger("saturacion");
                acelerometroUmbral = umbralesDocument.getInteger("acelerometroCaida");
                System.out.println("Parametros obtenidos de la base de datos:");
                System.out.println("Pulso: " + pulsoUmbral);
                System.out.println("Saturación: " + saturacionUmbral);
                System.out.println("Acelerómetro: " + acelerometroUmbral);
            }

            mongoClient.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public static void obtenerSensores() {
        try {
            ConnectionString connectionString = new ConnectionString("mongodb+srv://plataformaPMR:NT0RHvpfC0KMgbra@cluster0.cae2jjy.mongodb.net/platformtfm");
            MongoClientSettings settings = MongoClientSettings.builder().applyConnectionString(connectionString).build();
            MongoClient mongoClient = MongoClients.create(settings);
            MongoDatabase database = mongoClient.getDatabase("platformtfm");
            MongoCollection<Document> collection = database.getCollection("sensors");
            FindIterable<Document> sensors = collection.find();

            // Contar el número de sensores para inicializar los arrays
            long count = collection.countDocuments();
            sensorNames = new String[(int) count];
            sensorUmbrals = new int[(int) count];

            int index = 0;
            // Iterar sobre los sensores y guardar los nombres y umbrales
            try (MongoCursor<Document> cursor = sensors.iterator()) {
                while (cursor.hasNext()) {
                    Document sensor = cursor.next();
                    String name = sensor.getString("name");
                    int umbral = sensor.getInteger("umbral");
                    sensorNames[index] = name;
                    sensorUmbrals[index] = umbral;
                    index++;
                }
            }

            // Imprimir los sensores y sus umbrales
            System.out.println("Sensores obtenidos de la base de datos:");
            for (int i = 0; i < sensorNames.length; i++) {
                System.out.println("Sensor: " + sensorNames[i] + ", Umbral: " + sensorUmbrals[i]);
            }

            mongoClient.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public static class Mensaje {
        private int pulso;
        private int saturacion;
        private int acelerometro;

        public Mensaje(String mensajeJSON) {
            this.pulso = parsearPulsoDesdeJSON(mensajeJSON);
            this.saturacion = parsearSaturacionDesdeJSON(mensajeJSON);
            this.acelerometro = parsearAcelerometroDesdeJSON(mensajeJSON);
        }

        public int getPulso() {
            return pulso;
        }

        public int getSaturacion() {
            return saturacion;
        }

        public int getAcelerometro() {
            return acelerometro;
        }


        private int parsearPulsoDesdeJSON(String mensajeJSON) {
            try {

                JSONObject jsonObject = new JSONObject(mensajeJSON);
                return jsonObject.getInt("pulso");
            } catch (JSONException e) {
                System.err.println("Error al parsear el valor del pulso: " + e.getMessage());
                return -1;
            }
        }

        private int parsearSaturacionDesdeJSON(String mensajeJSON) {
            try {
                JSONObject jsonObject = new JSONObject(mensajeJSON);
                return jsonObject.getInt("saturacion");
            } catch (JSONException e) {

                System.err.println("Error al parsear el valor de saturación: " + e.getMessage());
                return -1;
            }
        }

        private int parsearAcelerometroDesdeJSON(String mensajeJSON) {
            try {
                JSONObject jsonObject = new JSONObject(mensajeJSON);
                return jsonObject.getInt("acelerometro");
            } catch (JSONException e) {
                System.err.println("Error al parsear el valor del acelerómetro: " + e.getMessage());
                return -1;
            }
        }
    }
}
