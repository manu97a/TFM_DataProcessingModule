
public class Main {
    public static void main(String[] args) {
        // Crear instancias de los Runnable
        Runnable clienteRunnable = new ClienteRunnable();
        Runnable sensoresRunnable = new SensoresRunnable();


        Thread clienteThread = new Thread(clienteRunnable);
        Thread sensoresThread = new Thread(sensoresRunnable);
        clienteThread.start();
        sensoresThread.start();
        try {
            clienteThread.join();
            sensoresThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
class ClienteRunnable implements Runnable {
    @Override
    public void run() {
        Cliente.main(new String[0]);
    }
}

class SensoresRunnable implements Runnable {
    @Override
    public void run() {
        Sensores.main(new String[0]);
    }
}