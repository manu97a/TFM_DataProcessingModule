import com.mongodb.client.*;
import org.eclipse.paho.client.mqttv3.*;
import com.espertech.esper.client.*;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;
import org.json.JSONObject;
import com.mongodb.client.model.Filters;
import org.bson.Document;
import com.mongodb.MongoClientSettings;
import com.mongodb.ConnectionString;
import java.util.HashMap;
import java.util.Map;

public class Sensores {
    private static Map<String, Integer> sensorThresholds = new HashMap<>();
    private static EPRuntime cepRT;

    public static void main(String[] args) {
        String broker = "ws://test.mosquitto.org:8080/mqtt";
        String clientId = "JavaMQTTSubscriber_Sensores";
        String topic = "TFM_Sensores";

        sensorThresholds = obtenerUmbralesSensores();

        // Configurar ESPER
        Configuration configuration = new Configuration();
        configuration.addEventType("SensorEvent", SensorEvent.class);
        EPServiceProvider cep = EPServiceProviderManager.getProvider("myCEPEngine", configuration);
        cepRT = cep.getEPRuntime();

        // Definir consulta Esper
        String epl = "select * from SensorEvent(sensorValue > threshold)";
        EPStatement stmt = cep.getEPAdministrator().createEPL(epl);
        stmt.addListener((newData, oldData) -> {
            SensorEvent event = (SensorEvent) newData[0].getUnderlying();
            System.out.println("Alerta: Valor del sensor " + event.getSensorName() + " excede el umbral!");
        });

        try {
            MqttClient client = new MqttClient(broker, clientId, new MemoryPersistence());
            client.setCallback(new MqttCallback() {
                public void connectionLost(Throwable cause) {
                    System.out.println("Conexión perdida con el broker MQTT");
                }

                public void messageArrived(String topic, MqttMessage message) throws Exception {
                    String payload = new String(message.getPayload());
                    System.out.println("Mensaje recibido en el topic " + topic + ": " + payload);

                    JSONObject json = new JSONObject(payload);
                    for (String sensorName : json.keySet()) {
                        int sensorValue = json.getInt(sensorName);
                        int threshold = sensorThresholds.get(sensorName);
                        cepRT.sendEvent(new SensorEvent(sensorName, sensorValue, threshold));
                    }
                }

                public void deliveryComplete(IMqttDeliveryToken token) {
                    // No se usa en el suscriptor
                }
            });

            client.connect();
            client.subscribe(topic);
            System.out.println("Conectado al broker MQTT y suscrito al tópico: " + topic);

        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    public static Map<String, Integer> obtenerUmbralesSensores() {
        Map<String, Integer> sensorThresholds = new HashMap<>();

        ConnectionString connectionString = new ConnectionString("mongodb+srv://plataformaPMR:NT0RHvpfC0KMgbra@cluster0.cae2jjy.mongodb.net/platformtfm");
        MongoClientSettings settings = MongoClientSettings.builder()
                .applyConnectionString(connectionString)
                .build();
        MongoClient mongoClient = MongoClients.create(settings);
        MongoDatabase database = mongoClient.getDatabase("platformtfm");
        MongoCollection<Document> collection = database.getCollection("sensors");
        MongoCursor<Document> cursor = collection.find().iterator();
        try {
            while (cursor.hasNext()) {
                Document sensor = cursor.next();
                String name = sensor.getString("name");
                int threshold = sensor.getInteger("umbral");
                sensorThresholds.put(name, threshold);
            }
        } finally {
            cursor.close();
        }
        for (Map.Entry<String, Integer> entry : sensorThresholds.entrySet()) {
            System.out.println("Nombre del sensor: " + entry.getKey() + ", Umbral: " + entry.getValue());
        }

        return sensorThresholds;
    }

    public static class SensorEvent {
        private String sensorName;
        private int sensorValue;
        private int threshold;

        public SensorEvent(String sensorName, int sensorValue, int threshold) {
            this.sensorName = sensorName;
            this.sensorValue = sensorValue;
            this.threshold = threshold;
        }

        public String getSensorName() {
            return sensorName;
        }

        public void setSensorName(String sensorName) {
            this.sensorName = sensorName;
        }

        public int getSensorValue() {
            return sensorValue;
        }

        public void setSensorValue(int sensorValue) {
            this.sensorValue = sensorValue;
        }

        public int getThreshold() {
            return threshold;
        }

        public void setThreshold(int threshold) {
            this.threshold = threshold;
        }
    }
}